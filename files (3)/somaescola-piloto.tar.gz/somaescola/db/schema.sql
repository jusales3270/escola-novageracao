-- SomaEscola — esquema do piloto
-- Postgres 16. Multi-tenant por escola, com RLS ligada em toda tabela.

create extension if not exists "pgcrypto";

create table escola (
  id            uuid primary key default gen_random_uuid(),
  razao_social  text not null,
  cnpj          text not null unique,
  cidade        text not null,
  criada_em     timestamptz not null default now()
);

-- ---------------------------------------------------------------- --
-- Preço: FONTE ÚNICA. A anuidade não é coluna. É mensalidade × 12,
-- calculada na leitura. Foi a existência de duas fontes gravadas em
-- lugares diferentes que produziu a divergência de R$ 1.729,05.
-- ---------------------------------------------------------------- --
create table tabela_preco (
  id                uuid primary key default gen_random_uuid(),
  escola_id         uuid not null references escola(id),
  ano_letivo        int  not null,
  vigencia_inicio   date not null,
  aprovada_por      text,
  aprovada_em       timestamptz,
  desconto_pontualidade_pct numeric(5,2) not null default 5,
  matricula_cheia   numeric(12,2) not null,
  unique (escola_id, ano_letivo)
);

create table preco_linha (
  id               uuid primary key default gen_random_uuid(),
  tabela_id        uuid not null references tabela_preco(id) on delete cascade,
  faixa            text not null,
  periodo          text not null check (periodo in ('MEIO','INTEGRAL')),
  mensalidade      numeric(12,2) not null check (mensalidade > 0),
  alimentacao_inclusa boolean not null default false,
  descricao_contrato  text not null,
  -- só para reconciliação contra o documento legado; nunca usada em cálculo
  anuidade_declarada_legado numeric(12,2),
  unique (tabela_id, faixa, periodo)
);

create view preco_efetivo as
  select l.*, round(l.mensalidade * 12, 2) as anuidade_derivada,
         round(l.mensalidade * 12, 2) - coalesce(l.anuidade_declarada_legado, round(l.mensalidade*12,2)) as delta_legado
    from preco_linha l;

-- ---------------------------------------------------------------- --
-- Cadastro único. É a origem de todo documento gerado.
-- ---------------------------------------------------------------- --
create table pessoa (
  id         uuid primary key default gen_random_uuid(),
  escola_id  uuid not null references escola(id),
  nome       text not null,
  cpf        text not null,
  email      text,
  telefone   text,
  unique (escola_id, cpf)
);

create table aluno (
  id           uuid primary key default gen_random_uuid(),
  escola_id    uuid not null references escola(id),
  nome         text not null,
  nascimento   date not null,
  endereco     text, bairro text, cidade text, cep text,
  restricao_judicial text,
  criado_em    timestamptz not null default now()
);

-- Dado sensível de criança em tabela própria: permite política de
-- acesso e criptografia distintas do cadastro comum (LGPD art. 11/14).
create table ficha_saude (
  aluno_id     uuid primary key references aluno(id) on delete cascade,
  dados        jsonb not null,
  prescricao_anexada boolean not null default false,
  atualizada_em timestamptz not null default now()
);

create table autorizado_retirada (
  id        uuid primary key default gen_random_uuid(),
  aluno_id  uuid not null references aluno(id) on delete cascade,
  nome      text not null, telefone text not null, vinculo text
);

-- ---------------------------------------------------------------- --
-- Matrícula e alterações. Contrato de educação não admite aditivo:
-- cada alteração gera novo requerimento e nova assinatura.
-- ---------------------------------------------------------------- --
create table matricula (
  id            text primary key,
  escola_id     uuid not null references escola(id),
  aluno_id      uuid not null references aluno(id),
  contratante_id uuid not null references pessoa(id),
  financeiro_id  uuid not null references pessoa(id),
  tabela_id     uuid not null references tabela_preco(id),
  ano_letivo    int not null,
  tipo          text not null check (tipo in ('MATRICULA','REMATRICULA')),
  turma         text not null,
  periodo       text not null,
  alimentacao   text not null default 'NENHUMA',
  fraldario     text not null default 'NENHUM',
  hora_adicional_dias int not null default 0,
  desconto_excepcional_pct numeric(5,2) not null default 0,
  justificativa_desconto text,
  autorizado_por text,
  decisao_motor text not null check (decisao_motor in ('LIBERADO','BLOQUEADO')),
  assinatura_logica text not null,
  criada_em     timestamptz not null default now()
);

create table alteracao_contratual (
  id           uuid primary key default gen_random_uuid(),
  matricula_id text not null references matricula(id),
  motivo       text not null,
  descricao    text not null,
  solicitado_por text not null,
  observacao   text,
  nova_matricula_id text references matricula(id),
  em           timestamptz not null default now()
);

-- ---------------------------------------------------------------- --
-- Consentimento de imagem: evento com vigência, nunca coluna booleana.
-- Cl. 16ª exige que seja revogável — logo precisa responder
-- "podia publicar naquela data?", não só "pode hoje?".
-- ---------------------------------------------------------------- --
create table consentimento_imagem (
  id           uuid primary key default gen_random_uuid(),
  matricula_id text not null references matricula(id),
  canal        text not null check (canal in
                 ('SITE','REDES_SOCIAIS','ALBUM_TURMA','USO_PEDAGOGICO_INTERNO','MATERIAL_IMPRESSO')),
  concedido    boolean not null,
  por_cpf      text not null,
  por_nome     text not null,
  canal_coleta text not null,
  em           timestamptz not null default now()
);
create index on consentimento_imagem (matricula_id, canal, em desc);

create or replace function pode_publicar(p_matricula text, p_canal text, p_quando timestamptz)
returns boolean language sql stable as $$
  select coalesce(
    (select concedido from consentimento_imagem
      where matricula_id = p_matricula and canal = p_canal and em <= p_quando
      order by em desc limit 1),
    false);  -- fail-closed: ausência de decisão nunca é autorização
$$;

-- ---------------------------------------------------------------- --
-- Documentos e envelope
-- ---------------------------------------------------------------- --
create table documento (
  id           uuid primary key default gen_random_uuid(),
  matricula_id text not null references matricula(id),
  tipo         text not null check (tipo in ('REQUERIMENTO','CONTRATO','ANEXO')),
  nome         text not null,
  sha256       text not null,
  bytes        int not null,
  caminho      text not null,
  gerado_em    timestamptz not null default now()
);

create table envelope (
  id            uuid primary key default gen_random_uuid(),
  matricula_id  text not null references matricula(id),
  provedor      text not null default 'DOCUSIGN',
  envelope_id   text not null,
  status        text not null,
  enviado_em    timestamptz not null default now(),
  concluido_em  timestamptz,
  unique (provedor, envelope_id)
);

create table envelope_signatario (
  id           uuid primary key default gen_random_uuid(),
  envelope_id  uuid not null references envelope(id) on delete cascade,
  papel        text not null check (papel in
                 ('CONTRATANTE','RESPONSAVEL_FINANCEIRO','ESCOLA','TESTEMUNHA')),
  nome         text not null, email text not null, cpf text,
  ordem        int not null,
  status       text not null default 'enviado',
  assinado_em  timestamptz
);

-- ---------------------------------------------------------------- --
-- Cadeia de evidência. Append-only por trigger.
-- ---------------------------------------------------------------- --
create table evento_ledger (
  seq           bigserial primary key,
  escola_id     uuid not null references escola(id),
  matricula_id  text,
  tipo          text not null,
  ator          text not null,
  payload       jsonb not null,
  hash_anterior text not null,
  hash          text not null unique,
  em            timestamptz not null default now()
);

create or replace function bloqueia_alteracao() returns trigger
language plpgsql as $$
begin
  raise exception 'evento_ledger é append-only (tentativa de % no seq %)', tg_op, old.seq;
end $$;

create trigger ledger_append_only
  before update or delete on evento_ledger
  for each row execute function bloqueia_alteracao();

-- ---------------------------------------------------------------- --
-- RLS: isolamento por escola em todas as tabelas com escola_id.
-- ---------------------------------------------------------------- --
do $$
declare t text;
begin
  foreach t in array array['tabela_preco','pessoa','aluno','matricula','evento_ledger'] loop
    execute format('alter table %I enable row level security', t);
    execute format('alter table %I force row level security', t);
    execute format($f$create policy tenant_%1$s on %1$I
      using (escola_id = current_setting('app.escola_id', true)::uuid)$f$, t);
  end loop;
end $$;
