import { z } from 'zod';
import { randomUUID } from 'node:crypto';
import {
  PedidoMatricula,
  Turma,
  Periodo,
  ROTULO_TURMA,
  type CanalImagem,
} from '../dominio/tipos.js';
import { avalia, buscaLinha, anuidadeDerivada, type Contexto, type VereditoFinal } from '../motor/index.js';
import { RegistroConsentimento } from '../consentimento/modelo.js';
import { ledger } from '../ledger/evidencia.js';
import { geraDocumentos } from '../documentos/render.js';
import { enviaEnvelope, type Signatario } from '../assinatura/envelope.js';
import type { DocusignClient } from '../assinatura/docusign-client.js';

/**
 * Safe Actions — toda entrada passa por Zod, todo efeito passa pelo motor,
 * todo resultado entra no ledger. Nenhuma ação escreve sem veredito.
 */

export class BloqueioMotor extends Error {
  constructor(public readonly veredito: VereditoFinal) {
    super(
      `Motor bloqueou a operação: ${veredito.bloqueios.map((b) => b.regra).join(', ')}`,
    );
    this.name = 'BloqueioMotor';
  }
}

/* ------------------------- criarMatricula ------------------------- */

export interface MatriculaCriada {
  matriculaId: string;
  veredito: VereditoFinal;
  consentimento: RegistroConsentimento;
}

export function criarMatricula(entrada: unknown, ctx: Contexto): MatriculaCriada {
  const pedido = PedidoMatricula.parse(entrada);
  const matriculaId = `MAT-${pedido.anoLetivo}-${randomUUID().slice(0, 8).toUpperCase()}`;

  ledger.registra('PEDIDO_RECEBIDO', matriculaId, pedido.operador.nome, {
    aluno: pedido.aluno.nome,
    turma: pedido.servicos.turma,
    periodo: pedido.servicos.periodo,
    tipo: pedido.tipo,
  });

  const veredito = avalia(pedido, ctx);

  ledger.registra(
    veredito.decisao === 'LIBERADO' ? 'VEREDITO_MOTOR' : 'BLOQUEIO_MOTOR',
    matriculaId,
    'motor',
    {
      decisao: veredito.decisao,
      assinaturaLogica: veredito.assinaturaLogica,
      bloqueios: veredito.bloqueios.map((b) => ({ regra: b.regra, achado: b.achado, dono: b.dono })),
    },
  );

  const consentimento = new RegistroConsentimento(matriculaId);
  for (const ev of pedido.consentimentos) consentimento.registrar(ev);

  return { matriculaId, veredito, consentimento };
}

/* ---------------------- gerarDocumentosEEnviar --------------------- */

export async function gerarEEnviar(opts: {
  matricula: MatriculaCriada;
  pedido: PedidoMatricula;
  ctx: Contexto;
  cliente: DocusignClient;
  dirSaida: string;
  webhookUrl?: string;
}) {
  const { matricula, pedido, ctx, cliente, dirSaida } = opts;
  if (matricula.veredito.decisao !== 'LIBERADO' || !matricula.veredito.calculo) {
    throw new BloqueioMotor(matricula.veredito);
  }

  const linha = buscaLinha(ctx.tabela, pedido.servicos.turma, pedido.servicos.periodo);

  const docs = await geraDocumentos(
    {
      matriculaId: matricula.matriculaId,
      pedido,
      calculo: matricula.veredito.calculo,
      consentimentos: matricula.consentimento.estadoEm(),
      testemunhas: ctx.testemunhas,
      assinaturaLogica: matricula.veredito.assinaturaLogica,
      geradoEm: new Date().toISOString(),
      anuidadeDerivada: anuidadeDerivada(linha),
    },
    dirSaida,
  );

  const signatarios: Signatario[] = [
    { nome: pedido.contratante.nome, email: pedido.contratante.email, cpf: pedido.contratante.cpf, papel: 'CONTRATANTE', ordem: 1 },
  ];
  if (pedido.responsavelFinanceiro.cpf !== pedido.contratante.cpf) {
    signatarios.push({
      nome: pedido.responsavelFinanceiro.nome,
      email: pedido.responsavelFinanceiro.email,
      cpf: pedido.responsavelFinanceiro.cpf,
      papel: 'RESPONSAVEL_FINANCEIRO',
      ordem: 2,
    });
  }
  signatarios.push({ nome: 'CNG Educação Ltda ME', email: 'secretaria@novageracaoitu.com.br', papel: 'ESCOLA', ordem: 3 });
  for (const t of ctx.testemunhas) {
    signatarios.push({ nome: t.nome, email: emailTestemunha(t.nome), cpf: t.cpf, papel: 'TESTEMUNHA', ordem: 4 });
  }

  const envelope = await enviaEnvelope(cliente, {
    matriculaId: matricula.matriculaId,
    alunoNome: pedido.aluno.nome,
    anoLetivo: pedido.anoLetivo,
    webhookUrl: opts.webhookUrl,
    signatarios,
    documentos: [
      { id: '1', nome: 'Requerimento de matrícula.pdf', base64: docs.requerimento.base64 },
      { id: '2', nome: 'Contrato de prestação de serviços educacionais.pdf', base64: docs.contrato.base64 },
    ],
  });

  return { docs, envelope, signatarios };
}

/* --------------------- registrarAlteracaoContratual --------------------- */

/**
 * Transição de turma (berçário → mini maternal quando a criança anda).
 * O contrato de educação não admite aditivo: cada alteração gera novo
 * requerimento e nova assinatura, com o histórico preservado na cadeia.
 */
export const AlteracaoContratual = z.object({
  matriculaId: z.string(),
  motivo: z.enum(['TRANSICAO_TURMA', 'MUDANCA_PERIODO', 'SERVICO_ADICIONAL', 'CANCELAMENTO_SERVICO', 'RESCISAO']),
  turmaDe: Turma.optional(),
  turmaPara: Turma.optional(),
  periodoDe: Periodo.optional(),
  periodoPara: Periodo.optional(),
  solicitadoPor: z.string(),
  observacao: z.string().optional(),
});

export function registrarAlteracao(entrada: unknown) {
  const a = AlteracaoContratual.parse(entrada);
  const descricao =
    a.motivo === 'TRANSICAO_TURMA' && a.turmaDe && a.turmaPara
      ? `${ROTULO_TURMA[a.turmaDe]} → ${ROTULO_TURMA[a.turmaPara]}`
      : a.motivo;
  const ev = ledger.registra('ALTERACAO_CONTRATUAL', a.matriculaId, a.solicitadoPor, {
    motivo: a.motivo,
    descricao,
    observacao: a.observacao,
    exigeNovoContrato: true,
  });
  return { evento: ev, descricao };
}

/* --------------------- revogarConsentimento --------------------- */

export function revogarConsentimento(
  registro: RegistroConsentimento,
  canal: CanalImagem,
  por: { nome: string; cpf: string },
) {
  registro.registrar({
    canal,
    concedido: false,
    em: new Date().toISOString(),
    porCpf: por.cpf,
    porNome: por.nome,
    canalColeta: 'PORTAL',
  });
  return registro.estadoEm();
}

const emailTestemunha = (nome: string) =>
  `${nome.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z]/g, '.')}@novageracaoitu.com.br`;
