import { mkdir, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { brl, cent, PedidoMatricula } from './dominio/tipos.js';
import {
  anuidadeDerivada,
  avalia,
  r01_reconciliaAnuidade,
  TABELA_2027,
  type Contexto,
} from './motor/index.js';
import { PARCELAS_ANUIDADE } from './motor/tabela-precos.js';
import { criarMatricula, gerarEEnviar, registrarAlteracao, revogarConsentimento, BloqueioMotor } from './acoes/index.js';
import { DocusignClient } from './assinatura/docusign-client.js';
import { ledger } from './ledger/evidencia.js';
import { PEDIDO_BERCARIO, PEDIDO_DESCONTO, PEDIDO_OK } from '../fixtures/pedidos.js';

const c = {
  ok: (s: string) => `\x1b[32m${s}\x1b[0m`,
  err: (s: string) => `\x1b[31m${s}\x1b[0m`,
  warn: (s: string) => `\x1b[33m${s}\x1b[0m`,
  dim: (s: string) => `\x1b[2m${s}\x1b[0m`,
  b: (s: string) => `\x1b[1m${s}\x1b[0m`,
};

const SAIDA = process.env.DIR_SAIDA ?? join(process.cwd(), 'saida');

function contexto(over: Partial<Contexto> = {}): Contexto {
  return {
    tabela: TABELA_2027,
    testemunhas: [
      { nome: 'Vanessa Prado', cpf: '52998224725' },
      { nome: 'Juliana Retz', cpf: '15350946056' },
    ],
    prescricaoAnexada: true,
    dpaAssinado: false,
    ambiente: 'homologacao',
    ...over,
  };
}

function titulo(t: string) {
  console.log(`\n${c.b(t)}\n${'─'.repeat(t.length)}`);
}

function imprimeVereditos(vs: { regra: string; titulo: string; conforme: boolean; severidade: string; detalhe: string; achado?: string; dono?: string }[]) {
  for (const v of vs) {
    const marca = v.conforme ? c.ok('  S ') : v.severidade === 'BLOQUEIA' ? c.err('  N ') : c.warn(' ED ');
    const ref = v.achado ? c.dim(` [${v.achado}]`) : '';
    console.log(`${marca} ${v.regra}  ${v.titulo}${ref}`);
    if (!v.conforme) console.log(`      ${c.dim(v.detalhe)}${v.dono ? c.dim(`  → ${v.dono}`) : ''}`);
  }
}

/* ------------------------------ comandos ------------------------------ */

function cmdReconciliar() {
  titulo('Reconciliação da tabela de preços 2027');
  console.log(
    c.dim('Turma / período').padEnd(46) +
      c.dim('mensal×12'.padStart(14)) +
      c.dim('contrato'.padStart(14)) +
      c.dim('Δ'.padStart(12)),
  );
  for (const l of TABELA_2027.linhas) {
    const v = r01_reconciliaAnuidade(l);
    const der = anuidadeDerivada(l);
    const delta = cent(l.anuidadeDeclaradaContrato - der);
    const linha =
      `${l.faixa}/${l.periodo}`.padEnd(46) +
      der.toFixed(2).padStart(14) +
      l.anuidadeDeclaradaContrato.toFixed(2).padStart(14) +
      delta.toFixed(2).padStart(12);
    console.log(v.conforme ? linha : c.err(linha));
    if (!v.conforme) {
      console.log(
        c.dim(
          `${' '.repeat(46)}mensalidade implícita no contrato: ${cent(l.anuidadeDeclaradaContrato / PARCELAS_ANUIDADE).toFixed(2)} × requerimento: ${l.mensalidade.toFixed(2)}`,
        ),
      );
    }
  }
}

function cmdGaps() {
  titulo('Gaps abertos — bloqueiam geração de documento');
  const ctx = contexto({ tabela: { ...TABELA_2027, aprovadaPor: 'Marlene Modesto da Silva' } });
  const p = (x: unknown) => PedidoMatricula.parse(x);
  const casos: [string, ReturnType<typeof avalia>][] = [
    ['Alfa I integral (caso feliz)', avalia(p(PEDIDO_OK), ctx)],
    ['Berçário integral', avalia(p(PEDIDO_BERCARIO), ctx)],
    ['Desconto de 18% pela secretaria', avalia(p(PEDIDO_DESCONTO), ctx)],
  ];
  for (const [nome, v] of casos) {
    console.log(`\n${c.b(nome)} → ${v.decisao === 'LIBERADO' ? c.ok(v.decisao) : c.err(v.decisao)}`);
    imprimeVereditos(v.vereditos.filter((x) => !x.conforme));
    if (v.decisao === 'LIBERADO') console.log(c.ok('  Todas as 12 regras conformes.'));
  }
}

async function cmdDemo() {
  await mkdir(SAIDA, { recursive: true });

  titulo('Fase 1 — Tabela de preços não aprovada');
  let ctx = contexto();
  let v = avalia(PedidoMatricula.parse(PEDIDO_OK), ctx);
  console.log(`Decisão: ${c.err(v.decisao)} — ${v.bloqueios.length} bloqueio(s)`);
  imprimeVereditos(v.bloqueios);
  console.log(c.dim('\n  O motor se recusa a gerar documento a partir de tabela sem aprovação.'));

  titulo('Fase 2 — Direção aprova a tabela');
  ctx = contexto({ tabela: { ...TABELA_2027, aprovadaPor: 'Marlene Modesto da Silva' } });
  const m = criarMatricula(PEDIDO_OK, ctx);
  console.log(`Matrícula ${c.b(m.matriculaId)} → ${c.ok(m.veredito.decisao)}`);
  imprimeVereditos(m.veredito.vereditos);
  const calc = m.veredito.calculo!;
  console.log(
    `\n  Mensalidade ${c.b(brl(calc.mensal.totalCheio))} · com pontualidade ${c.b(brl(calc.mensal.totalComPontualidade))}`,
  );
  console.log(`  Matrícula ${calc.matricula.pct}% em ${calc.matricula.parcelas}× de ${c.b(brl(calc.matricula.valorParcela))}`);
  console.log(`  Anuidade derivada ${c.b(brl(calc.anuidade))}`);

  titulo('Fase 3 — Consentimento de imagem por canal');
  for (const k of m.consentimento.estadoEm()) {
    console.log(`  ${k.concedido ? c.ok('AUTORIZA    ') : c.err('NÃO AUTORIZA')} ${k.rotulo}`);
  }

  titulo('Fase 4 — Documentos gerados e envelope enviado');
  const cliente = new DocusignClient({
    integrationKey: process.env.DS_INTEGRATION_KEY ?? '',
    userId: process.env.DS_USER_ID ?? '',
    privateKeyPem: process.env.DS_PRIVATE_KEY ?? '',
    oauthBase: process.env.DS_OAUTH_BASE ?? 'account-d.docusign.com',
    mock: process.env.DS_MODO !== 'real',
  });

  const r = await gerarEEnviar({
    matricula: m,
    pedido: PEDIDO_OK,
    ctx,
    cliente,
    dirSaida: SAIDA,
    webhookUrl: process.env.DS_WEBHOOK,
  });
  console.log(`  ${c.ok('PDF')} ${r.docs.requerimento.arquivoPdf.split('/').pop()}  ${(r.docs.requerimento.bytes / 1024).toFixed(0)} KB  sha256 ${r.docs.requerimento.sha256.slice(0, 16)}…`);
  console.log(`  ${c.ok('PDF')} ${r.docs.contrato.arquivoPdf.split('/').pop()}  ${(r.docs.contrato.bytes / 1024).toFixed(0)} KB  sha256 ${r.docs.contrato.sha256.slice(0, 16)}…`);
  console.log(`\n  Envelope ${c.b(r.envelope.envelopeId)} · status ${r.envelope.status} · modo ${cliente.emMock ? c.warn('MOCK') : c.ok('DOCUSIGN')}`);
  console.log(`  ${c.b(String(r.signatarios.length))} signatários:`);
  for (const s of r.signatarios) console.log(`    ${s.ordem}. ${s.papel.padEnd(24)} ${s.nome}`);

  titulo('Fase 5 — Berçário integral: motor bloqueia');
  const mb = criarMatricula(PEDIDO_BERCARIO, ctx);
  console.log(`Matrícula ${mb.matriculaId} → ${c.err(mb.veredito.decisao)}`);
  imprimeVereditos(mb.veredito.bloqueios);
  try {
    await gerarEEnviar({ matricula: mb, pedido: PEDIDO_BERCARIO, ctx, cliente, dirSaida: SAIDA });
    console.log(c.err('  FALHA: documento foi gerado apesar do bloqueio.'));
  } catch (e) {
    if (e instanceof BloqueioMotor) console.log(c.ok('  Geração recusada. Nenhum PDF, nenhum envelope, nenhum e-mail ao responsável.'));
    else throw e;
  }

  titulo('Fase 6 — Transição de turma e revogação de consentimento');
  const alt = registrarAlteracao({
    matriculaId: m.matriculaId,
    motivo: 'TRANSICAO_TURMA',
    turmaDe: 'BERCARIO',
    turmaPara: 'MINI_MATERNAL',
    solicitadoPor: 'Coordenação',
    observacao: 'Criança começou a andar — Cl. 12ª §4º, novo requerimento e nova assinatura.',
  });
  console.log(`  ${alt.descricao} — evento #${alt.evento.seq}, exige novo contrato`);
  revogarConsentimento(m.consentimento, 'ALBUM_TURMA', {
    nome: PEDIDO_OK.contratante.nome,
    cpf: PEDIDO_OK.contratante.cpf,
  });
  console.log(`  Álbum da turma revogado → hoje: ${m.consentimento.podePublicar('ALBUM_TURMA') ? c.err('pode') : c.ok('não pode')}`);
  console.log(`  Em 22/08/2026 antes da revogação: ${m.consentimento.podePublicar('ALBUM_TURMA', '2026-08-22T14:00:00.000Z') ? c.ok('podia') : c.err('não podia')}`);

  titulo('Fase 7 — Cadeia de evidência');
  const integridade = ledger.verifica();
  console.log(`  ${ledger.trilha().length} eventos · integridade ${integridade.integra ? c.ok('ÍNTEGRA') : c.err(`ROMPIDA no #${integridade.rompeuEm}`)}`);
  console.log(`  Raiz: ${c.dim(ledger.raiz)}`);
  for (const e of ledger.trilha().slice(0, 12)) {
    console.log(`    ${String(e.seq).padStart(2)}  ${e.tipo.padEnd(26)} ${c.dim(e.hash.slice(0, 12))}  ${e.ator}`);
  }
  if (ledger.trilha().length > 12) console.log(c.dim(`    … +${ledger.trilha().length - 12} eventos`));

  await writeFile(join(SAIDA, 'trilha.json'), JSON.stringify(ledger.trilha(), null, 2));
  console.log(`\n${c.dim(`Artefatos em ${SAIDA}`)}`);
}

/* -------------------------------- main -------------------------------- */

const cmd = process.argv[2] ?? 'demo';
const rotas: Record<string, () => void | Promise<void>> = {
  demo: cmdDemo,
  reconciliar: cmdReconciliar,
  gaps: cmdGaps,
};
const fn = rotas[cmd];
if (!fn) {
  console.error(`Comando desconhecido: ${cmd}. Use: ${Object.keys(rotas).join(' | ')}`);
  process.exit(2);
}
await fn();
