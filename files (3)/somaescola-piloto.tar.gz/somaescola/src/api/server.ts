import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { join, dirname, basename } from 'node:path';
import { ZodError } from 'zod';
import { avalia, TABELA_2027, type Contexto } from '../motor/index.js';
import { PedidoMatricula } from '../dominio/tipos.js';
import { criarMatricula, gerarEEnviar } from '../acoes/index.js';
import { DocusignClient } from '../assinatura/docusign-client.js';
import { ledger } from '../ledger/evidencia.js';
import { processaEvento, verificaAssinatura, type EventoConnect } from '../assinatura/webhook.js';

const AQUI = dirname(new URL(import.meta.url).pathname);
const PORTA = Number(process.env.PORTA ?? 3000);
const SEGREDO_CONNECT = process.env.DS_CONNECT_HMAC ?? '';
const SAIDA = process.env.DIR_SAIDA ?? join(process.cwd(), 'saida');

const ctx = (): Contexto => ({
  tabela: { ...TABELA_2027, aprovadaPor: process.env.TABELA_APROVADA_POR || null },
  testemunhas: (process.env.TESTEMUNHAS ?? 'Vanessa Prado:52998224725,Juliana Retz:15350946056')
    .split(',')
    .filter(Boolean)
    .map((t) => {
      const [nome, cpf] = t.split(':');
      return { nome: (nome ?? '').trim(), cpf: (cpf ?? '').trim() };
    }),
  prescricaoAnexada: true,
  dpaAssinado: process.env.DPA_ASSINADO === 'true',
  ambiente: (process.env.AMBIENTE as Contexto['ambiente']) ?? 'homologacao',
});

const cliente = () =>
  new DocusignClient({
    integrationKey: process.env.DS_INTEGRATION_KEY ?? '',
    userId: process.env.DS_USER_ID ?? '',
    privateKeyPem: process.env.DS_PRIVATE_KEY ?? '',
    oauthBase: process.env.DS_OAUTH_BASE ?? 'account-d.docusign.com',
    mock: process.env.DS_MODO !== 'real',
  });

type Res = import('node:http').ServerResponse;
const json = (res: Res, code: number, body: unknown) => {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(body, null, 2));
};

const corpo = (req: import('node:http').IncomingMessage) =>
  new Promise<string>((ok, err) => {
    let b = '';
    req.on('data', (c) => (b += c));
    req.on('end', () => ok(b));
    req.on('error', err);
  });

/** Rótulo legível do campo pendente, para a secretaria saber o que falta. */
const ROTULO_CAMPO: Record<string, string> = {
  'aluno.nome': 'Nome do aluno',
  'aluno.nascimento': 'Data de nascimento',
  'aluno.endereco': 'Endereço',
  'aluno.bairro': 'Bairro',
  'aluno.cep': 'CEP',
  'aluno.ficha.contatoEmergenciaNome': 'Contato de emergência — nome',
  'aluno.ficha.contatoEmergenciaFone': 'Contato de emergência — telefone',
  'contratante.nome': 'Contratante — nome',
  'contratante.cpf': 'Contratante — CPF',
  'contratante.email': 'Contratante — e-mail',
  'contratante.telefone': 'Contratante — telefone',
  'responsavelFinanceiro.nome': 'Responsável financeiro — nome',
  'responsavelFinanceiro.cpf': 'Responsável financeiro — CPF',
  'responsavelFinanceiro.email': 'Responsável financeiro — e-mail',
  'responsavelFinanceiro.telefone': 'Responsável financeiro — telefone',
};

function pendencias(e: ZodError) {
  return e.issues.map((i) => {
    const caminho = i.path.join('.');
    return { campo: caminho, rotulo: ROTULO_CAMPO[caminho] ?? caminho, motivo: i.message };
  });
}

const servidor = createServer(async (req, res) => {
  const url = new URL(req.url ?? '/', `http://localhost:${PORTA}`);

  try {
    if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) {
      const html = await readFile(join(AQUI, 'app.html'), 'utf8');
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(html);
    }

    if (req.method === 'GET' && url.pathname === '/config') {
      const c = ctx();
      return json(res, 200, {
        ambiente: c.ambiente,
        anoLetivo: c.tabela.anoLetivo,
        tabelaAprovadaPor: c.tabela.aprovadaPor,
        testemunhas: c.testemunhas,
        dpaAssinado: c.dpaAssinado,
        modoAssinatura: process.env.DS_MODO === 'real' ? 'DOCUSIGN' : 'MOCK',
        precos: c.tabela.linhas.map((l) => ({
          faixa: l.faixa,
          periodo: l.periodo,
          mensalidade: l.mensalidade,
          alimentacaoInclusa: l.alimentacaoInclusa,
        })),
        adicionais: c.tabela.adicionais,
        matriculaCheia: c.tabela.matriculaCheia,
      });
    }

    if (req.method === 'POST' && url.pathname === '/simular') {
      let pedido;
      try {
        pedido = PedidoMatricula.parse(JSON.parse(await corpo(req)));
      } catch (e) {
        if (e instanceof ZodError) return json(res, 200, { decisao: 'INCOMPLETO', pendencias: pendencias(e) });
        throw e;
      }
      const v = avalia(pedido, ctx());
      return json(res, 200, {
        decisao: v.decisao,
        calculo: v.calculo,
        vereditos: v.vereditos,
        bloqueios: v.bloqueios,
        alertas: v.alertas,
        assinaturaLogica: v.assinaturaLogica,
      });
    }

    if (req.method === 'POST' && url.pathname === '/emitir') {
      let pedido;
      try {
        pedido = PedidoMatricula.parse(JSON.parse(await corpo(req)));
      } catch (e) {
        if (e instanceof ZodError) return json(res, 422, { decisao: 'INCOMPLETO', pendencias: pendencias(e) });
        throw e;
      }
      const c = ctx();
      const m = criarMatricula(pedido, c);
      if (m.veredito.decisao !== 'LIBERADO') {
        return json(res, 422, {
          matriculaId: m.matriculaId,
          decisao: m.veredito.decisao,
          bloqueios: m.veredito.bloqueios,
        });
      }
      const r = await gerarEEnviar({
        matricula: m,
        pedido,
        ctx: c,
        cliente: cliente(),
        dirSaida: SAIDA,
        webhookUrl: process.env.DS_WEBHOOK,
      });
      return json(res, 201, {
        matriculaId: m.matriculaId,
        decisao: 'LIBERADO',
        assinaturaLogica: m.veredito.assinaturaLogica,
        documentos: [
          { tipo: 'Requerimento de matrícula', arquivo: basename(r.docs.requerimento.arquivoPdf), sha256: r.docs.requerimento.sha256, bytes: r.docs.requerimento.bytes },
          { tipo: 'Contrato de prestação de serviços', arquivo: basename(r.docs.contrato.arquivoPdf), sha256: r.docs.contrato.sha256, bytes: r.docs.contrato.bytes },
        ],
        envelope: { id: r.envelope.envelopeId, status: r.envelope.status, modo: process.env.DS_MODO === 'real' ? 'DOCUSIGN' : 'MOCK' },
        signatarios: r.signatarios,
        consentimentos: m.consentimento.estadoEm(),
      });
    }

    if (req.method === 'GET' && url.pathname.startsWith('/documentos/')) {
      const nome = basename(decodeURIComponent(url.pathname.slice('/documentos/'.length)));
      const buf = await readFile(join(SAIDA, nome));
      res.writeHead(200, { 'Content-Type': 'application/pdf', 'Content-Disposition': `inline; filename="${nome}"` });
      return res.end(buf);
    }

    if (req.method === 'POST' && url.pathname === '/ds/webhook') {
      const cru = await corpo(req);
      const hmac = String(req.headers['x-docusign-signature-1'] ?? '');
      if (SEGREDO_CONNECT && !verificaAssinatura(cru, hmac, SEGREDO_CONNECT)) {
        return json(res, 401, { erro: 'assinatura HMAC inválida' });
      }
      return json(res, 200, processaEvento(JSON.parse(cru) as EventoConnect));
    }

    if (req.method === 'GET' && url.pathname === '/trilha') {
      const id = url.searchParams.get('matricula') ?? undefined;
      return json(res, 200, { integridade: ledger.verifica(), raiz: ledger.raiz, eventos: ledger.trilha(id) });
    }

    if (req.method === 'GET' && url.pathname === '/saude') return json(res, 200, { ok: true, ambiente: ctx().ambiente });

    json(res, 404, { erro: 'rota não encontrada' });
  } catch (e) {
    json(res, 400, { erro: e instanceof Error ? e.message : String(e) });
  }
});

servidor.listen(PORTA, () => console.log(`SomaEscola em http://localhost:${PORTA}`));
