import { createHmac, timingSafeEqual } from 'node:crypto';
import { ledger } from '../ledger/evidencia.js';

/**
 * Docusign Connect — recebe mudanças de status do envelope.
 *
 * A assinatura HMAC vem no header `x-docusign-signature-1`, calculada
 * sobre o corpo cru da requisição com a chave configurada no Connect.
 * Verificar isso não é opcional: sem ela, qualquer um pode declarar
 * um contrato como assinado.
 */

export function verificaAssinatura(corpoCru: string, headerHmac: string, segredo: string): boolean {
  const calc = createHmac('sha256', segredo).update(corpoCru, 'utf8').digest('base64');
  const a = Buffer.from(calc);
  const b = Buffer.from(headerHmac);
  return a.length === b.length && timingSafeEqual(a, b);
}

export interface EventoConnect {
  event: string;
  data: {
    envelopeId: string;
    envelopeSummary?: {
      status: string;
      customFields?: { textCustomFields?: { name: string; value: string }[] };
      recipients?: { signers?: { name: string; status: string; signedDateTime?: string }[] };
    };
  };
}

export function processaEvento(ev: EventoConnect) {
  const env = ev.data.envelopeSummary;
  const matriculaId =
    env?.customFields?.textCustomFields?.find((f) => f.name === 'matriculaId')?.value ??
    'desconhecida';

  switch (ev.event) {
    case 'recipient-completed':
      for (const s of env?.recipients?.signers ?? []) {
        if (s.status === 'completed') {
          ledger.registra('SIGNATARIO_ASSINOU', matriculaId, s.name, {
            envelopeId: ev.data.envelopeId,
            em: s.signedDateTime,
          });
        }
      }
      break;
    case 'envelope-completed':
      ledger.registra('ENVELOPE_CONCLUIDO', matriculaId, 'docusign', {
        envelopeId: ev.data.envelopeId,
      });
      break;
    default:
      ledger.registra('ENVELOPE_ENVIADO', matriculaId, 'docusign', {
        envelopeId: ev.data.envelopeId,
        evento: ev.event,
        status: env?.status,
      });
  }
  return { matriculaId, evento: ev.event };
}
