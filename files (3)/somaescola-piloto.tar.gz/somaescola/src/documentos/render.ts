import { execFile } from 'node:child_process';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { promisify } from 'node:util';
import { hashDocumento } from '../ledger/evidencia.js';
import { contratoHtml, requerimentoHtml, type DadosDocumento } from './templates.js';

const exec = promisify(execFile);

export interface Artefato {
  nome: string;
  arquivoHtml: string;
  arquivoPdf: string;
  base64: string;
  sha256: string;
  bytes: number;
}

async function renderiza(html: string, base: string, dir: string): Promise<Artefato> {
  await mkdir(dir, { recursive: true });
  const htmlPath = join(dir, `${base}.html`);
  const pdfPath = join(dir, `${base}.pdf`);
  await writeFile(htmlPath, html, 'utf8');

  const script = join(dirname(new URL(import.meta.url).pathname), '../../scripts/render_pdf.py');
  await exec('python3', [script, htmlPath, pdfPath]);

  const buf = await readFile(pdfPath);
  return {
    nome: base,
    arquivoHtml: htmlPath,
    arquivoPdf: pdfPath,
    base64: buf.toString('base64'),
    sha256: hashDocumento(buf),
    bytes: buf.length,
  };
}

export async function geraDocumentos(d: DadosDocumento, dir: string) {
  const requerimento = await renderiza(
    requerimentoHtml(d),
    `requerimento-${d.matriculaId}`,
    dir,
  );
  const contrato = await renderiza(contratoHtml(d), `contrato-${d.matriculaId}`, dir);
  return { requerimento, contrato };
}
