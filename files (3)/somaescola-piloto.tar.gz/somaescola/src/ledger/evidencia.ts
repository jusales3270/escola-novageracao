import { createHash } from 'node:crypto';

/**
 * Cadeia de evidência. Cada evento carrega o hash do anterior, então
 * alterar um registro antigo invalida toda a cadeia à frente.
 *
 * Por que importa aqui: contrato de menor, prazo prescricional que não
 * corre normalmente contra criança, dado sensível de saúde. O arquivo
 * precisa provar não só o que foi assinado, mas quando e por quem.
 */

export type TipoEvento =
  | 'PEDIDO_RECEBIDO'
  | 'VEREDITO_MOTOR'
  | 'DOCUMENTO_GERADO'
  | 'ENVELOPE_CRIADO'
  | 'ENVELOPE_ENVIADO'
  | 'SIGNATARIO_ASSINOU'
  | 'ENVELOPE_CONCLUIDO'
  | 'DOCUMENTO_ARQUIVADO'
  | 'CONSENTIMENTO_REGISTRADO'
  | 'CONSENTIMENTO_REVOGADO'
  | 'ALTERACAO_CONTRATUAL'
  | 'BLOQUEIO_MOTOR';

export interface Evento {
  seq: number;
  em: string;
  tipo: TipoEvento;
  ator: string;
  matriculaId: string;
  payload: Record<string, unknown>;
  hashAnterior: string;
  hash: string;
}

const GENESE = '0'.repeat(64);

export class Ledger {
  private eventos: Evento[] = [];

  registra(
    tipo: TipoEvento,
    matriculaId: string,
    ator: string,
    payload: Record<string, unknown>,
    em = new Date().toISOString(),
  ): Evento {
    const anterior = this.eventos.at(-1);
    const hashAnterior = anterior?.hash ?? GENESE;
    const seq = this.eventos.length + 1;
    const corpo = JSON.stringify({ seq, em, tipo, ator, matriculaId, payload, hashAnterior });
    const hash = createHash('sha256').update(corpo).digest('hex');
    const ev: Evento = { seq, em, tipo, ator, matriculaId, payload, hashAnterior, hash };
    this.eventos.push(ev);
    return ev;
  }

  /** Reprocessa a cadeia inteira e aponta o primeiro elo rompido. */
  verifica(): { integra: boolean; rompeuEm?: number } {
    let anterior = GENESE;
    for (const e of this.eventos) {
      const corpo = JSON.stringify({
        seq: e.seq,
        em: e.em,
        tipo: e.tipo,
        ator: e.ator,
        matriculaId: e.matriculaId,
        payload: e.payload,
        hashAnterior: anterior,
      });
      const esperado = createHash('sha256').update(corpo).digest('hex');
      if (esperado !== e.hash || e.hashAnterior !== anterior) {
        return { integra: false, rompeuEm: e.seq };
      }
      anterior = e.hash;
    }
    return { integra: true };
  }

  trilha(matriculaId?: string): Evento[] {
    return matriculaId ? this.eventos.filter((e) => e.matriculaId === matriculaId) : [...this.eventos];
  }

  get raiz(): string {
    return this.eventos.at(-1)?.hash ?? GENESE;
  }
}

export const hashDocumento = (buf: Buffer | string) =>
  createHash('sha256').update(buf).digest('hex');

export const ledger = new Ledger();
