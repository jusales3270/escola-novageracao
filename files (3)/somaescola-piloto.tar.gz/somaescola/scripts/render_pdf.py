#!/usr/bin/env python3
"""Renderiza HTML -> PDF (A4) com Chromium headless.

Uso: render_pdf.py entrada.html saida.pdf

Isolado num script proprio porque o binario do Chromium e a unica
dependencia pesada do piloto. Em producao isso vira um worker BullMQ
com pool de paginas; a interface (html na entrada, pdf na saida) nao muda.
"""
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright


def main() -> int:
    if len(sys.argv) != 3:
        print("uso: render_pdf.py <entrada.html> <saida.pdf>", file=sys.stderr)
        return 2
    entrada, saida = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
    saida.parent.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.goto(entrada.as_uri())
        page.wait_for_load_state("networkidle")
        page.pdf(
            path=str(saida),
            format="A4",
            print_background=True,
            margin={"top": "0", "bottom": "0", "left": "0", "right": "0"},
        )
        browser.close()
    print(str(saida))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
