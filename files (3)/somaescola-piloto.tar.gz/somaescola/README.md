# SomaEscola — piloto CNG Educação

Motor determinístico do ciclo **requerimento → contrato → assinatura → arquivo**
para o Grupo Nova Geração em Educação (CNG Educação Ltda ME, Itu/SP).

Implementa o Módulo 1 definido no diagnóstico `SVS/CNG-001`. Fora de escopo,
por decisão registrada: nota fiscal de serviço, FOA, fluxo de caixa, compras,
CRM e portal de fotos.

```
npm install
npm run app           # aplicação em http://localhost:3000
npm run reconciliar   # confronta a tabela de preços contra o contrato legado
npm run gaps          # mostra o que hoje bloqueia geração de documento
npm run demo          # executa o fluxo inteiro pela linha de comando
npm test              # 29 testes, fixtures congeladas
```

## A aplicação

`npm run app` sobe a tela que a secretaria usa. Uma página só, na ordem do
papel que ela já preenche: matrícula, aluno, serviços, responsáveis, ficha de
saúde, autorização de imagem.

À direita fica o **painel do motor**, que reavalia as doze regras a cada tecla
digitada e mostra o veredito ao vivo — S, ED ou N, a mesma legenda do FOA e do
diagnóstico. Enquanto faltam campos, o painel diz o que falta. Quando o pedido
fica completo, ou libera com a composição de preço calculada, ou bloqueia
dizendo qual regra impediu, qual achado a originou e quem decide.

O botão de emitir só existe habilitado quando as doze regras passam. Trocar a
turma para Berçário Integral bloqueia na hora, com R-01 e R-02 acesas em
vermelho — é o gap A-01 aparecendo antes do contrato existir, não depois.

Emitindo: gera os dois PDFs com hash SHA-256, monta o envelope Docusign com os
signatários na ordem de roteamento e mostra a cadeia de evidência do início ao
fim. Os PDFs abrem direto do painel.

| Rota | Uso |
|---|---|
| `GET /` | a aplicação |
| `POST /simular` | veredito ao vivo, sem persistir nada |
| `POST /emitir` | gera PDFs, cria envelope, grava no ledger |
| `GET /documentos/:arquivo` | abre o PDF gerado |
| `POST /ds/webhook` | Docusign Connect, com HMAC verificado |
| `GET /trilha` | cadeia de evidência e verificação de integridade |

---

## Doutrina

O motor decide. O documento apenas expressa a decisão. Nenhum modelo de
linguagem participa de nenhum veredito — se um LLM entrar no produto depois,
ele narra este resultado, nunca o produz. Mesma entrada, mesmo veredito,
sempre, e a `assinaturaLogica` (SHA-256 da entrada + vereditos) prova isso.

**Fail-closed.** Nenhuma regra bloqueante em aberto permite gerar documento.
É por isso que o piloto pode ser entregue com os gaps ainda em discussão:
ele não produz o contrato errado — recusa-se a produzir qualquer contrato
até a escola decidir. A recusa é útil por si só, porque nomeia quem decide.

**Fonte única de preço.** A anuidade não é digitada em lugar nenhum. É
derivada da mensalidade × 12, na leitura. A divergência de R$ 1.729,05 no
berçário integral existe justamente porque hoje há duas fontes: a mensalidade
no requerimento e a anuidade na Cláusula 8ª.

---

## As doze regras

| Regra | O que verifica | Achado | Decide |
|---|---|---|---|
| R-01 | Anuidade do contrato reconcilia com mensalidade × 12 | A-01 | Direção |
| R-02 | Alimentação inclusa não é cobrada de novo como adicional | A-02 | Direção |
| R-03 | Desconto dentro da alçada de quem concede | A-08 | Direção |
| R-04 | Consentimento de imagem decidido canal a canal | A-04 | Jurídico |
| R-05 | Medicação autorizada tem prescrição anexada | A-05 | Secretaria |
| R-06 | Duas testemunhas nomeadas com CPF | A-06 | Direção |
| R-07 | Tabela de preços aprovada pela direção | — | Direção |
| R-08 | Ano letivo do pedido bate com o da tabela | A-09 | Secretaria |
| R-09 | Responsável financeiro identificado | — | Secretaria |
| R-10 | Pessoas autorizadas à retirada registradas | — | Secretaria |
| R-11 | Escada de desconto da matrícula é aritmética | A-03 | Direção |
| R-12 | Contrato de tratamento de dados assinado | — | Jurídico |

Os achados referenciam o diagnóstico documental `SVS/CNG-001`, de 22/08/2026.

---

## Gaps abertos

Cada um bloqueia geração. Nenhum é resolvido por código.

| Gap | Pendência | Efeito hoje |
|---|---|---|
| G-01 | Preço do berçário integral: R$ 44.327,28 ou R$ 46.056,33 | R-01 bloqueia berçário integral |
| G-02 | Alimentação do berçário: inclusa ou adicional | R-02 bloqueia quando há adicional |
| G-03 | Aprovação da tabela 2027 pela direção | R-07 bloqueia tudo |
| G-04 | Definição das duas testemunhas | R-06 bloqueia tudo |
| G-05 | Parecer jurídico sobre consentimento por canal | R-04 usa os 5 canais provisórios |
| G-06 | DPA controlador/operador assinado | R-12 bloqueia produção |

O motor roda hoje em `homologacao` com dados fictícios. G-06 é o que separa
homologação de produção: nenhum dado real de criança entra antes disso.

---

## Fluxo

```
Pedido (Zod)
   ↓
Motor — 12 regras determinísticas
   ↓                        ↘ BLOQUEADO → ledger + nada mais acontece
LIBERADO
   ↓
Documentos HTML → PDF (Chromium)  ·  SHA-256 de cada arquivo
   ↓
Envelope Docusign — 4 a 5 signatários com âncoras AutoPlace
   ↓
Connect webhook (HMAC verificado) → ledger
   ↓
Arquivo com cadeia de evidência encadeada
```

### Signatários

Achado A-06: o contrato exige duas testemunhas com CPF. São **quatro a cinco
signatários por envelope**, não dois — o que muda o custo de assinatura e
precisa ser decidido antes de contratar o provedor.

| Ordem | Papel | Âncora |
|---|---|---|
| 1 | Contratante / responsável legal | `/ass_contratante/` |
| 2 | Responsável financeiro (omitido se for a mesma pessoa) | `/ass_financeiro/` |
| 3 | Escola | `/ass_escola/` |
| 4 | Testemunhas 1 e 2, em paralelo | `/ass_testemunha/` |

As testemunhas preservam a eficácia executiva do contrato (CPC art. 784, III) —
é o que sustenta a cobrança da escola.

### Docusign

JWT Grant server-to-server: assertion RS256 → `POST /oauth/token` →
`GET /oauth/userinfo` para descobrir `accountId` e `base_uri` →
`POST /restapi/v2.1/accounts/{accountId}/envelopes`.

Na primeira execução com um integration key novo, o consentimento precisa ser
concedido uma vez pela URL que o cliente devolve no erro `consent_required`.

`DS_MODO=mock` roda o fluxo inteiro sem credenciais — é o modo do piloto.

---

## HTML → PDF, e não docxtemplater

O contrato revisado tem 23 cláusulas e cabe em duas páginas; o requerimento é
máscara de preenchimento. Reconstruir em HTML custou pouco e eliminou a classe
inteira de defeitos herdada dos `.docx`: tabela aninhada dentro de tabela, PNG
de 154 KB no cabeçalho de cada FOA, resíduo de "exercício 2026" no documento
de 2027.

A contrapartida é real e está registrada: a advogada deixa de editar o contrato
sozinha no Word. Se ela exigir controle editorial, o `.docx` dela passa a ser
fonte normativa e o template aqui vira a implementação — com um teste de
equivalência entre os dois. Decisão dela, não nossa.

---

## Consentimento de imagem

A Cláusula 16ª exige autorização específica, destacada, facultativa e
**revogável**. Revogável significa série temporal de eventos, não coluna
booleana: o sistema precisa responder *"esta foto podia ser publicada naquela
data?"*, não apenas *"pode hoje?"*.

Cinco finalidades separadas: site, redes sociais, álbum da turma, uso
pedagógico interno, material impresso. Sem evento explícito de concessão, a
resposta é **não** — ausência de decisão nunca vira autorização.

Este é o ponto de origem da dificuldade com o ECA que a direção vem
enfrentando. A solução não está no site nem em aplicativo: está no formulário
de matrícula.

---

## Estrutura

```
src/
  dominio/tipos.ts          Zod, vocabulário do domínio, validação de CPF
  motor/
    tabela-precos.ts        fonte única, vigência, valores legados p/ auditoria
    regras.ts               R-01 … R-12
    calculo.ts              composição mensal e escada de matrícula
    index.ts                orquestrador fail-closed
  documentos/               templates HTML + render PDF
  consentimento/modelo.ts   consentimento event-sourced
  assinatura/               cliente JWT, envelope, webhook Connect
  ledger/evidencia.ts       cadeia SHA-256
  acoes/                    Safe Actions
  api/server.ts             HTTP: /simular /matriculas /ds/webhook /trilha
db/schema.sql               Postgres com RLS e ledger append-only
fixtures/pedidos.ts         casos congelados
tests/motor.test.ts         29 testes
```

## Produção

Ainda não implementado, e deliberadamente: persistência Postgres (o schema
existe, o repositório é em memória), fila BullMQ para o pico de rematrícula,
e o pool de Chromium como worker. A interface não muda — HTML entra, PDF sai.

Calendário: o prazo de 50% da rematrícula 2027 vence em 31/08/2026. A safra
2027 será processada manualmente. Este piloto mira a safra seguinte, com as
transições de turma ao longo de 2027 servindo de teste real e de baixo volume.
